#! /usr/bin/perl
################################################################################
################################################################################
# Author:  Christian Jungreuthmayer
# Date:    Thu Dec 12 13:44:27 CET 2013
# Company: Austrian Centre of Industrial Biotechnology (ACIB)
################################################################################

use strict;
use warnings;

# use constant CONSIDER_ZERO => 1e-8;
use constant CONSIDER_ZERO => 1e-5;
my @efms;
my @sorted;
my @sorted_tmp;
my $cnt = 0;
my $histo;

while(<>)
{
   s/^\s+//;
   s/\s+$//;
   s/\s+/ /g;
   my @val = split;
   my @bin = map{ abs($_) < CONSIDER_ZERO ? 0 : 1} @val;
   # print "bin: @bin\n";

   my $card = 0;
   foreach (@bin){ $card++ if $_ != 0 };
   # print "card: $card\n";

   my $hash;
   $hash->{vals} = \@val;
   $hash->{bins} = \@bin;
   $hash->{strg} = join("-", @bin);
   $hash->{card} = $card;
   $hash->{orig} = $cnt;
   my $nume = scalar(@val);
   $hash->{nume} = scalar(@val);
   
   push @efms, $hash;
   # print "in: @bin: card=$card orig=$cnt nume=$nume\n";
   $histo->{$card}++;
   $cnt++;
}

@sorted_tmp = sort {$a->{strg} cmp $b->{strg} } @efms;
@sorted = sort {$a->{card} <=> $b->{card} } @sorted_tmp;


# for( my $i = 0; $i < @sorted; $i++ )
# {
#    print "sort_b: @{$sorted[$i]->{bins}}: card=$sorted[$i]->{card} orig=$sorted[$i]->{orig}\n";
#    print "sort_v: @{$sorted[$i]->{vals}}: num elems: ", scalar(@{$sorted[$i]->{vals}}),"\n";
# }

print "total number of modes: $cnt\n";

my $modes_cnt = 0;
foreach my $c (sort { $a <=> $b} keys %$histo )
{
   print "card: $c, number of modes: $histo->{$c}\n";
   for( my $i = 0; $i < $cnt; $i++ )
   {
      # print "before next: i=$i/$cnt $c card=$efms->[$i]{card} orig=$efms->[$i]{orig}\n";
      next unless $sorted[$i]->{card} == $c;
      # print "after next: i=$i/$cnt $c card=$efms->[$i]{card} orig=$efms->[$i]{orig}\n";
      print "   b $modes_cnt: @{$sorted[$i]->{bins}}\n";
      print "   v $modes_cnt: @{$sorted[$i]->{vals}}\n";
      $modes_cnt++;
   }
}
