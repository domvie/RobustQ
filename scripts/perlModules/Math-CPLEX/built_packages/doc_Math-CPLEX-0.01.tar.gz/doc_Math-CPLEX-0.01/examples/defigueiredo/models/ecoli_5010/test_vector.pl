#! /usr/bin/perl
################################################################################
################################################################################
# Author:  Christian Jungreuthmayer
# Date:    Fri Oct 25 13:41:39 CEST 2013
# Company: Austrian Centre of Industrial Biotechnology (ACIB)
################################################################################

use strict;
use warnings;

use Getopt::Std;
use vars qw($opt_s $opt_m $opt_r $opt_v $opt_o $opt_h $opt_l $opt_t);

use constant M             => -1000;
use constant CONSIDER_ZERO => 1e-8;

my ($sfile,$mfile,$rfile,$rvfile,$efm_filename);
my ($cplex_env,$lp);
my $num_reacs_expand;
my ($solutions,$sol_norm);
my $solution_cnt = 0;
my $write_lp_file = 0;
my $num_threads = 1;
my $row_sum_zr_ge_1;

read_arguments();

my $reacs = read_reactions($rfile);
warn "reacs: @$reacs\n";

my $metas = read_metabolites($mfile);
warn "metas: @$metas\n";

my $rever = read_reversibility($rvfile);
warn "rever: @$rever\n";

my $stoim = read_stoichiomat($sfile);
print_matrix("stoich:\n", $stoim);

# my $vec = [1.4999999985,4.4999999955,2.999999997,1.4999999985,1.4999999985,2.999999997,-2.999999997,-2.999999997,2.999999997,1.4999999985,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1.999999998,0.999999999,0,1.999999998,1.999999998,1.999999998,0,0,0,0,0,1.4999999985,0,0,0,0,0,0,0,0,0,0,0,0,1.999999998,0.999999999,0,0,0,0,2.999999997,0.999999999,2.999999997,1.999999998,0,0,0,1.4999999985,0,0,0,0,0,0,0,0,1.999999998];
my $vec = [1,1,0,1,1,2,-2,-2,2,4,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,1,1,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,3,1,1,0,0,0,2,0,1,0,1,2,0,0,1,0,0,0,0,0,0,0,0,0];

my $res = multiply($stoim,$vec);
print_vec("result: \n", $res);
################################################################################


################################################################################
################################################################################
sub multiply
{
   my $mat = shift;
   my $vec = shift;
   my $out;

   my $num_row = @{$mat};
   my $num_col = @{$mat->[0]};

   die "number of columns not ok" if $num_col != @$vec;

   for( my $r = 0; $r < $num_row; $r++ )
   {
      $out->[$r] = 0;
      for( my $c = 0; $c < $num_col; $c++ )
      {
         $out->[$r] += $mat->[$r][$c]*$vec->[$c];
      }
   }
   return $out;
}
################################################################################


################################################################################
################################################################################
sub setLength
{
   my $inp = shift;
   my $len = shift;

   while( length $inp < $len )
   {
      $inp = '0' . $inp;
   }

   return $inp;
}
################################################################################


################################################################################
# reaction file has one line that contains a list of the reaction names
# the reaction names are separated by white spaces
################################################################################
sub read_stoichiomat
{
   my $file = shift;
   my $sm;

   open my $fh, $file or die "ERROR: couldn't open file '$file' for reading: $!\n";

   while( <$fh> )
   {
      my @st_facs = split;
      push @$sm, \@st_facs;
   }

   close $fh;

   return $sm;
}
################################################################################


################################################################################
# reaction file has one line that contains a list of the reaction names
# the reaction names are separated by white spaces
################################################################################
sub read_reversibility
{
   my $file = shift;
   my $rvs;

   open my $fh, $file or die "ERROR: couldn't open file '$file' for reading: $!\n";
   $_ = <$fh>;
   @$rvs = split;
   close $fh;

   return $rvs;
}
################################################################################

################################################################################
# reaction file has one line that contains a list of the reaction names
# the reaction names are separated by white spaces
################################################################################
sub read_metabolites
{
   my $file = shift;
   my $mbs;

   open my $fh, $file or die "ERROR: couldn't open file '$file' for reading: $!\n";
   $_ = <$fh>;
   s/"//g;
   s/_//g;
   s/#//g;
   @$mbs = split;
   close $fh;

   return $mbs;
}
################################################################################


################################################################################
# reaction file has one line that contains a list of the reaction names
# the reaction names are separated by white spaces
################################################################################
sub read_reactions
{
   my $file = shift;
   my $rcs;

   open my $fh, $file or die "ERROR: couldn't open file '$file' for reading: $!\n";
   $_ = <$fh>;
   s/"//g;
   s/>//g;
   s/_//g;
   s/#//g;
   @$rcs = split;
   close $fh;

   return $rcs;
}
################################################################################


################################################################################
# read in program options
################################################################################
sub read_arguments
{
   getopts('s:m:r:v:o:hlt:');

   if( $opt_h )
   {
      usage();
   }

   if( $opt_s )
   {
      $sfile = $opt_s;
   }
   else
   {
      usage('ERROR: name of input file containing stoichiometric matrix not provided ',-1);
   }

   if( $opt_m )
   {
      $mfile = $opt_m;
   }
   else
   {
      usage('ERROR: name of input file containing metabolite names not provided ',-1);
   }

   if( $opt_r )
   {
      $rfile = $opt_r;
   }
   else
   {
      usage('ERROR: name of input file containing reaction names not provided ',-1);
   }

   if( $opt_v )
   {
      $rvfile = $opt_v;
   }
   else
   {
      usage('ERROR: name of input file containing reaction reversibility information not provided ',-1);
   }
}
################################################################################


################################################################################
################################################################################
sub expand_reac_names
{
   my $r_names = shift;
   my $rv      = shift;
   my $exp_names;

   for( my $i = 0; $i < @$r_names; $i++ )
   {
      push @$exp_names, $r_names->[$i];

      push @$exp_names, $r_names->[$i] . '_rev' if $rv->[$i] != 0;
   }

   return $exp_names;
}
################################################################################


################################################################################
################################################################################
sub resolv_reversible_reac
{
   my $s = shift;
   my $r = shift;
   my $splice_pos = 0;
   my $new_s;

   # copy existing stoichiometric
   for( my $m = 0; $m < @$s; $m++ )
   {
      for( my $r = 0; $r < @{$s->[$m]}; $r++ )
      {
         $new_s->[$m][$r] = $s->[$m][$r];
      }
   }

   for( my $r = 0; $r < @$rever; $r++ )
   {
      $splice_pos++;
      if( $rever->[$r] )
      {
         # warn "We found a reversible reaction at position $r\n";
         for( my $m = 0; $m < @$s; $m++ )
         {
            # warn "split reversible reaction into two irreversible reaction for metabolite $m\n";
            splice @{$new_s->[$m]}, $splice_pos, 0, -$s->[$m][$r];
         }
         $splice_pos++;
      }
   }

   return $new_s;
}
################################################################################


################################################################################
################################################################################
sub print_vec
{
   my $message = shift;
   my $vector  = shift;

   warn $message;

   for( my $r = 0; $r < @$vector; $r++ )
   {
      print STDERR "$vector->[$r]\n";
   }
}
################################################################################


################################################################################
################################################################################
sub print_matrix
{
   my $message = shift;
   my $matrix  = shift;

   warn $message;

   for( my $m = 0; $m < @$matrix; $m++ )
   {
      for( my $r = 0; $r < @{$matrix->[$m]}; $r++ )
      {
         print STDERR "\t$matrix->[$m][$r]";
      }
      warn "\n";
   }
}
################################################################################


################################################################################
################################################################################
sub usage
{
   my $message   = shift || '';
   my $exit_code = shift || 0;

   print "$message\n" if $message;

   print "defigueiredo.pl -s sfile -m file -r rfile -v rvfile [-h]\n";
   print "\n";
   print "-s ..... name of file containing stoichiometric matrix (input)\n";
   print "-m ..... name of file containing metabolites (input)\n";
   print "-r ..... name of file containing eactions (input)\n";
   print "-v ..... name of file containing reversibility information (input)\n";
   print "-h ..... print this message\n";
   print "\n";
   print "test_vector.pl computes elementary flux modes of a given metabolic system\n";

   exit($exit_code);
}
################################################################################
